$(function() {
    $('.menu-burger').click(function() {
        $('.menu-burger, .menu').toggleClass('active');
    });


    $('.clients-boxes').slick({
        centerMode: true,
        centerPadding: '0',
        arrows: true,
        dots: false,

        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 830,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                dots: false,
                arrows: true
            }
        }]
    })
})